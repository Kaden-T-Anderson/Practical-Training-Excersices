#!/bin/bash
grep -i "$1:00:00 $2" $3_Dealer_schedule.txt | awk -F" " '{print $1, $2, $5, $6}'
